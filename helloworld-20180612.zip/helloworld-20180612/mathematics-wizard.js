let _ = require('lodash');

module.exports = {

    performMagic: function(num1, num2) {
        console.log("Abracadacra!");

        return _.add(num1, num2);
    }
};